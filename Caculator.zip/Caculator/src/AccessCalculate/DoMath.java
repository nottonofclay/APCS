package AccessCalculate;
import CalculateLibrary.Calculate;

public class DoMath 
{
    public static void main(String[] args) 
    {
    	System.out.println(Calculate.gcf(81, 13));
    	Calculate.sebastionIsGood();

    }
}